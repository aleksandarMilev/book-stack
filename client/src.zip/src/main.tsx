import '@/i18n';
import '@/styles/index.css';

import React from 'react';
import ReactDOM from 'react-dom/client';

import { App } from '@/app/App';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
